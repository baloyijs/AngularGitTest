import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GithubService } from '../../github.service';


@Component({
  selector: 'app-repository-detail',
  templateUrl: './repository-detail.component.html',
  styleUrls: ['./repository-detail.component.scss']
})
export class RepositoryDetailComponent implements OnInit {
  @Input() owner: string = '';
  @Input() repo: string = '';
  repository: any = {};

  constructor(private route: ActivatedRoute, private githubService: GithubService) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.owner = params.get('owner') || '';
      this.repo = params.get('repo') || '';
      this.loadRepositoryDetails();
    });
  }

  loadRepositoryDetails(): void {
    this.githubService.getRepository(this.owner, this.repo).subscribe((response: any) => {
      this.repository = response || {};
    });
  }
}
