import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
 import { SearchComponent } from './SearchComponent/search/search.component';

import { RepositoryDetailComponent } from './RepositoryDetailComponent/repository-detail/repository-detail.component';

import { IssueListComponent } from './IssueListComponent/issue-list/issue-list.component';

 import { PieChartComponent } from './PieChartComponent/pie-chart/pie-chart.component';

const routes: Routes = [
    { path: '', redirectTo: '/search', pathMatch: 'full' }, // Default route redirects to the search component
    { path: 'search', component: SearchComponent }, // Route for the search component
    { path: 'details/:owner/:repoName', component: RepositoryDetailComponent }, // Route for repository details with dynamic parameters
    { path: 'issues/:owner/:repoName', component:IssueListComponent }, // Route for issues list with dynamic parameters
    { path: 'chart/:owner/:repoName', component:PieChartComponent }, // Route for pie chart with dynamic parameters
    { path: '**', redirectTo: '/search' } // Redirect invalid routes to the search component
  ];
  @NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }
  
