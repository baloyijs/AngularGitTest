import { Component, Input, OnInit } from '@angular/core';
import { GithubService } from '../../github.service';


@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.scss']
})
export class PieChartComponent implements OnInit {
  @Input() owner: string = '';
  @Input() repo: string = '';
  chartData: any[] = [];

  constructor(private githubService: GithubService) { }

  ngOnInit(): void {
    this.loadChartData();
  }

  loadChartData(): void {
    this.githubService.getIssuesCount(this.owner, this.repo).subscribe((response: any) => {
      const openCount = response.filter((issue: any) => issue.state === 'open').length;
      const closedCount = response.length - openCount;

      this.chartData = [
        { name: 'Open Issues', value: openCount },
        { name: 'Closed Issues', value: closedCount }
      ];
    });
  }
}
