import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { RepositoryDetailComponent } from "./RepositoryDetailComponent/repository-detail/repository-detail.component";
import { IssueListComponent } from './IssueListComponent/issue-list/issue-list.component';


@Component({
    selector: 'app-root',
    standalone: true,
    templateUrl: './app.component.html',
    styleUrl: './app.component.scss',
    //imports: [RouterOutlet, RepositoryDetailComponent, IssueListComponent]
})
export class AppComponent {
  title = 'github-sphiwe';
}
