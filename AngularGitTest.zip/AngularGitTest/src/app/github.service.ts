import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GithubService {
  getRepository: any;
  getIssuesCount(owner: string, repo: string) {
    throw new Error('Method not implemented.');
  }
  getIssues(owner: string, repo: string) {
    throw new Error('Method not implemented.');
  }
  private apiUrl = 'https://api.github.com';

  constructor(private http: HttpClient) {}

  searchRepositories(query: string): Observable<any> {
    const url = `${this.apiUrl}/search/repositories?q=${query}`;
    return this.http.get(url);
  }

  getRepositoryDetails(owner: string, repo: string): Observable<any> {
    const url = `${this.apiUrl}/repos/${owner}/${repo}`;
    return this.http.get(url);
  }

  getIssuesList(owner: string, repo: string, state: string): Observable<any> {
    const url = `${this.apiUrl}/repos/${owner}/${repo}/issues?state=${state}`;
    return this.http.get(url);
  }
}
