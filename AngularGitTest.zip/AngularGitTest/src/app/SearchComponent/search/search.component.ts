import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { GithubService } from '../../github.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent {
  searchTerm: string = '';

  constructor(private router: Router, private githubService: GithubService) {}

  searchRepositories(): void {
    if (this.searchTerm.trim()) {
      this.githubService.searchRepositories(this.searchTerm).subscribe((response: any) => {
        // Navigate to the search results page passing the search term as a parameter
        this.router.navigate(['/search-results', { q: this.searchTerm }]);
      });
    }
  }
}
