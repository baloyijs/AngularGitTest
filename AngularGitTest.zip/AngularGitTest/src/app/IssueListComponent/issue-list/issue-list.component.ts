import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GithubService } from '../../github.service';
// import { GithubService } from '../services/github.service';

@Component({
  selector: 'app-issue-list',
  templateUrl: './issue-list.component.html',
  styleUrls: ['./issue-list.component.scss']
})
export class IssueListComponent implements OnInit {
  owner: string = '';
  repo: string = '';
  issues: any[] = [];
  filteredIssues: any[] = [];
  selectedState: string = 'open';

  constructor(private route: ActivatedRoute, private githubService: GithubService) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.owner = params.get('owner') || '';
      this.repo = params.get('repo') || '';
      this.loadIssues();
    });
  }

  loadIssues(): void {
    this.githubService.getIssues(this.owner, this.repo).subscribe((response: any) => {
      this.issues = response.items || [];
      this.filteredIssues = this.filterIssuesByState(this.selectedState);
    });
  }

  filterIssuesByState(state: string): any[] {
    return this.issues.filter(issue => issue.state.toLowerCase() === state.toLowerCase());
  }

  filterIssues(): void {
    this.filteredIssues = this.filterIssuesByState(this.selectedState);
  }
}
